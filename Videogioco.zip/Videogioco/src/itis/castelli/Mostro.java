package itis.castelli;

public class Mostro {
    String nome;
    int salute;
    int attaccoPrincipale;
    int superAttacco;
    int difesa;
    int vita;

    public Mostro(String nome, int salute, int attaccoPrincipale, int superAttacco, int difesa) {
        this.nome = nome;
        this.salute = salute;
        this.attaccoPrincipale = attaccoPrincipale;
        this.superAttacco = superAttacco;
        this.difesa = difesa;
        this.vita = salute;  // La vita iniziale è pari alla salute
    }

    // Metodo per attaccare un altro giocatore
    public void attacca(Mostro avversario, boolean usaSuper) {
        int danno;
        if (usaSuper) {
            danno = this.superAttacco;  // Se usaSuper è true, assegna il super attacco
        } else {
            danno = this.attaccoPrincipale;  // Se usaSuper è false, assegna l'attacco principale
        }
        avversario.subisciDanno(danno);
    }

    // Metodo per subire danno
    public void subisciDanno(int danno) {
        int dannoEffettivo = Math.max(danno - this.difesa, 0); // Danno ridotto dalla difesa, non può essere negativo
        this.vita -= dannoEffettivo;
        if (this.vita < 0) this.vita = 0; // La vita non può scendere sotto zero
    }
    // Metodo per curarsi
    public void curarsi(){
        this.vita= vita+difesa;
    }

    public int getVita() {
        return this.vita;
    }

    public void difendi() {
    }
}
