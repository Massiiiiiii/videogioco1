package itis.castelli;

public class Davide extends Mostro {

    public Davide() {
        super("Davide", 4000, 1000, 5000, 100);
    }
}
