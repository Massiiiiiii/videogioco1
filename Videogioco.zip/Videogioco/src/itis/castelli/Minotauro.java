package itis.castelli;

public class Minotauro extends Mostro {

    public Minotauro() {
        super("Minotauro", 8000, 900, 1200, 200);
    }
}
