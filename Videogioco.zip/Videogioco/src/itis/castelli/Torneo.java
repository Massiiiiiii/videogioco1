package itis.castelli;

import java.util.Random;
import java.util.Scanner;

public class Torneo {
    int turni = 9;
    Scanner scelta = new Scanner(System.in);
    int attacchiGiocatore = 0;
    int attacchiAvversario = 0;
    boolean superAttaccoDisponibileGiocatore = true;
    boolean superAttaccoDisponibileAvversario = true;
    int turniAttaccoSuperGiocatore = 0;
    int turniAttaccoSuperAvversario = 0;

    public void iniziaPartita() {
        System.out.println("Benvenuto al torneo in modalità single-player!");

        int sceltaMito; // Continua a chiedere fino a quando viene scelta una opzione valida
        Mostro giocatore;
        do {
            System.out.println("Inserisci il numero del mito che vuoi scegliere (1-6): ");
            System.out.println("1) Drago di fuoco (salute 10000), attacco principale: spara fuoco(500), super: palla fuoco (1000), Difesa: Velo oscuro");
            System.out.println("2) Grifone (salute 6000), attacco principale: folata(700), super: colpo di frusta (1100), Difesa: Protezione");
            System.out.println("3) Minotauro (salute 8000), attacco principale: cornata(900), super: carica (1200), Difesa: Nube d'ombra");
            System.out.println("4) Davide (salute 4000), attacco principale: fionda(1000), super: sasso gigante (5000), Difesa: Base di roccia");
            System.out.println("5) Fuffy (salute 5000), attacco principale: morso triplo(300), super: tre fuochi (1200), Difesa: Pelle pietra");
            System.out.println("6) Cupido (salute 7000), attacco principale: freccie dirette(900), super: pioggia di freccie (2000), Difesa: Difesa amorosa");
            sceltaMito = scelta.nextInt();
            giocatore = creaMito(sceltaMito);
        } while (giocatore == null);

        // Il computer sceglie un avversario casuale
        Random rand = new Random();
        int mitoAvversario = rand.nextInt(6) + 1;  // Sceglie un numero tra 1 e 6 per il mito dell'avversario
        Mostro avversario = creaMito(mitoAvversario);  // Crea il mito dell'avversario

        // Se il giocatore e l'avversario sono lo stesso mito, rifa la scelta del mito
        while (giocatore.nome.equals(avversario.nome)) {
            System.out.println("Non puoi avere lo stesso mito come avversario. Scegli di nuovo un mito.");
            do {
                System.out.println("Inserisci il numero del mito che vuoi scegliere (1-6): ");
                sceltaMito = scelta.nextInt();
                giocatore = creaMito(sceltaMito);  // Crea il mito del giocatore
            } while (giocatore == null); // Continua a chiedere fino a quando viene scelta una opzione valida

            // Il computer sceglie di nuovo un avversario
            mitoAvversario = rand.nextInt(6) + 1;  // Sceglie un numero tra 1 e 6 per il mito dell'avversario
            avversario = creaMito(mitoAvversario);  // Crea il mito dell'avversario
        }

        System.out.println("Hai scelto " + giocatore.nome); //scelta giocatore
        System.out.println("Il tuo avversario è " + avversario.nome); //scelta computer

        // alternanza turni
        for (int turno = 1; turno <= turni; turno++) {
            System.out.println("\nTurno " + turno);

            // Mostra la vita dei miti prima di ogni attacco
            System.out.println(giocatore.nome + " ha " + giocatore.getVita() + " vita.");
            System.out.println(avversario.nome + " ha " + avversario.getVita() + " vita.");

            // Se uno dei miti ha 0 vita, la partita finisce prima
            if (giocatore.getVita() <= 0) {
                System.out.println(giocatore.nome + " è stato sconfitto. " + avversario.nome + " vince!");
                break;
            } else if (avversario.getVita() <= 0) {
                System.out.println(avversario.nome + " è stato sconfitto. " + giocatore.nome + " vince!");
                break;
            }

            // Giocatore attacca
            System.out.println(giocatore.nome + ", è il tuo turno!");
            int mossa1 = 0;  // Variabile per memorizzare la scelta dell'attacco
            boolean usaSuper1 = false;  // Determina se usare il super attacco

            // verifica se possibile utilizzare la super
            if (attacchiGiocatore == 2) {
                if (superAttaccoDisponibileGiocatore) {
                    System.out.println("Vuoi usare l'attacco base (1), il super (2), o curarti (3)?");
                    mossa1 = scelta.nextInt();
                    if (mossa1 == 2) {
                        usaSuper1 = true;  // Usa il super attacco se scelto
                        superAttaccoDisponibileGiocatore = false;  // Blocca il super attacco dopo l'uso
                        turniAttaccoSuperGiocatore = 0;  // Resetta il contatore dei turni
                    }
                } else {
                    System.out.println("Il super attacco non è disponibile, usa solo l'attacco principale (1) o curati (3).");
                    mossa1 = scelta.nextInt();
                }
            } else {
                System.out.println("Vuoi usare l'attacco base (1) o curarti (3)?");
                mossa1 = scelta.nextInt();
            }

            // Gestione delle mosse del giocatore
            if (mossa1 == 1) {
                giocatore.attacca(avversario, false);  // Usa l'attacco principale
            } else if (mossa1 == 2 && usaSuper1) {
                giocatore.attacca(avversario, true);   // Usa il super attacco
            } else if (mossa1 == 3) {
                System.out.println(giocatore.nome + " si è curato!");
                giocatore.curarsi();  // Il giocatore decide di curarsi
            } else {
                System.out.println("Scelta non valida, il turno è saltato.");
            }

            // Incremento attacchi giocatore per super
            attacchiGiocatore++;

            // Avversario attacca
            System.out.println(avversario.nome + " sta giocando!");

            // Avverario sceglie se usare la super
            boolean usaSuper2 = false;
            if (attacchiAvversario == 2) {
                if (superAttaccoDisponibileAvversario) {
                    usaSuper2 = rand.nextBoolean();  // Decide se usare il super attacco
                }
            }

            if (usaSuper2) {
                System.out.println(avversario.nome + " usa il super attacco!");
                avversario.attacca(giocatore, true);  // Avversario usa il super attacco
                attacchiAvversario = 0;
            } else {
                boolean siDifende = rand.nextInt(10) < 4;  // Avversario ha il 40% di probabilità di difendersi
                if (siDifende) {
                    System.out.println(avversario.nome + " si difende!");
                    avversario.difendi();  // Se si difende
                } else {
                    System.out.println(avversario.nome + " attacca!");
                    avversario.attacca(giocatore, false);  // Attacco normale
                    attacchiAvversario++;  // Incrementa gli attacchi dell'avversario per super
                }
            }



            // Gestione cooldown per il super attacco
            if (!superAttaccoDisponibileGiocatore) {
                turniAttaccoSuperGiocatore++;
                if (turniAttaccoSuperGiocatore >= 2) {
                    superAttaccoDisponibileGiocatore = true;  // Riabilita il super attacco dopo 2 turni
                }
            }

            if (!superAttaccoDisponibileAvversario) {
                turniAttaccoSuperAvversario++;
                if (turniAttaccoSuperAvversario >= 2) {
                    superAttaccoDisponibileAvversario = true;  // Riabilita il super attacco dopo 2 turni
                }
            }
        }

        // Risultato finale
        System.out.println("\nFine della partita!");
        System.out.println(giocatore.nome + " ha " + giocatore.getVita() + " vita rimasta.");
        System.out.println(avversario.nome + " ha " + avversario.getVita() + " vita rimasta.");

        if (giocatore.getVita() > avversario.getVita()) {
            System.out.println(giocatore.nome + " vince!");
        } else if (avversario.getVita() > giocatore.getVita()) {
            System.out.println(avversario.nome + " vince!");
        } else {
            System.out.println("Pareggio!");
        }
    }

    // Metodo per creare il mito basato sulla scelta
    public Mostro creaMito(int sceltaMito) {
        switch (sceltaMito) {
            case 1:
                return new Drago();
            case 2:
                return new Grifone();
            case 3:
                return new Minotauro();
            case 4:
                return new Davide();
            case 5:
                return new Fuffy();
            case 6:
                return new Cupido();
            default:
                System.out.println("Scelta non valida.");
                return null;
        }
    }

    public static void main(String[] args) {
        Torneo torneo = new Torneo();
        torneo.iniziaPartita();
    }
}
