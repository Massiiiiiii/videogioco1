package itis.castelli;

public class Drago extends Mostro {

    public Drago() {
        super("Drago di Fuoco", 10000, 500, 1000, 0);
    }
}
