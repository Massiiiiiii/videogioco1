package itis.castelli;

public class Cupido extends Mostro {

    public Cupido() {
        super("Cupido", 7000, 900, 2000, 200);
    }
}
