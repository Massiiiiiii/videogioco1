package itis.castelli;

public class Grifone extends Mostro {

    public Grifone() {
        super("Grifone", 6000, 700, 1100, 300);
    }
}
