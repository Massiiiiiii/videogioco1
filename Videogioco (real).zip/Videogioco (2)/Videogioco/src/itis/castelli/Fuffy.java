package itis.castelli;

public class Fuffy extends Mostro {

    public Fuffy() {
        super("Fuffy", 5000, 300, 1200, 100);
    }
}
